/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Entity;

import java.time.LocalDate;

/**
 *
 * @author ADMIN
 */
public class ChiTietPhieuMuon {

    int ID;
    int idPhieu;
    int idSach;
    String tenSach;
    int soLuong;
    LocalDate ngayMuon;
    String ngayTra,ngay_tra_thuc_te;
 
    boolean trangThai;

    public ChiTietPhieuMuon() {
    }

    public ChiTietPhieuMuon(int ID, int idPhieu, int idSach, String tenSach, int soLuong, LocalDate ngayMuon, String ngayTra, String ngay_tra_thuc_te, boolean trangThai) {
        this.ID = ID;
        this.idPhieu = idPhieu;
        this.idSach = idSach;
        this.tenSach = tenSach;
        this.soLuong = soLuong;
        this.ngayMuon = ngayMuon;
        this.ngayTra = ngayTra;
        this.ngay_tra_thuc_te = ngay_tra_thuc_te;
        this.trangThai = trangThai;
    }

    public int getID() {
        return ID;
    }

    public void setID(int ID) {
        this.ID = ID;
    }

    public int getIdPhieu() {
        return idPhieu;
    }

    public void setIdPhieu(int idPhieu) {
        this.idPhieu = idPhieu;
    }

    public int getIdSach() {
        return idSach;
    }

    public void setIdSach(int idSach) {
        this.idSach = idSach;
    }

    public String getTenSach() {
        return tenSach;
    }

    public void setTenSach(String tenSach) {
        this.tenSach = tenSach;
    }

    public int getSoLuong() {
        return soLuong;
    }

    public void setSoLuong(int soLuong) {
        this.soLuong = soLuong;
    }

    public LocalDate getNgayMuon() {
        return ngayMuon;
    }

    public void setNgayMuon(LocalDate ngayMuon) {
        this.ngayMuon = ngayMuon;
    }

    public String getNgayTra() {
        return ngayTra;
    }

    public void setNgayTra(String ngayTra) {
        this.ngayTra = ngayTra;
    }

    public String getNgay_tra_thuc_te() {
        return ngay_tra_thuc_te;
    }

    public void setNgay_tra_thuc_te(String ngay_tra_thuc_te) {
        this.ngay_tra_thuc_te = ngay_tra_thuc_te;
    }

    public boolean isTrangThai() {
        return trangThai;
    }

    public void setTrangThai(boolean trangThai) {
        this.trangThai = trangThai;
    }

    
}
