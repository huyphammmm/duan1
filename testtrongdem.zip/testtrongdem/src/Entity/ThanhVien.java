/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Entity;

/**
 *
 * @author ADMIN
 */
public class ThanhVien {
    private int id;
    private String ten_thanh_vien, nam_sinh, dia_chi, so_dien_thoai, email;

    public ThanhVien() {
    }

    public ThanhVien(int id, String ten_thanh_vien, String nam_sinh, String dia_chi, String so_dien_thoai, String email) {
        this.id = id;
        this.ten_thanh_vien = ten_thanh_vien;
        this.nam_sinh = nam_sinh;
        this.dia_chi = dia_chi;
        this.so_dien_thoai = so_dien_thoai;
        this.email = email;
    }

    public int getId() {
        return id;
    }

    public String getTen_thanh_vien() {
        return ten_thanh_vien;
    }

    public String getNam_sinh() {
        return nam_sinh;
    }

    public String getDia_chi() {
        return dia_chi;
    }

    public String getSo_dien_thoai() {
        return so_dien_thoai;
    }

    public String getEmail() {
        return email;
    }

    public void setId(int id) {
        this.id = id;
    }

    public void setTen_thanh_vien(String ten_thanh_vien) {
        this.ten_thanh_vien = ten_thanh_vien;
    }

    public void setNam_sinh(String nam_sinh) {
        this.nam_sinh = nam_sinh;
    }

    public void setDia_chi(String dia_chi) {
        this.dia_chi = dia_chi;
    }

    public void setSo_dien_thoai(String so_dien_thoai) {
        this.so_dien_thoai = so_dien_thoai;
    }

    public void setEmail(String email) {
        this.email = email;
    }
    
    
    
}
