    /*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package view_2;
import java.awt.Frame;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.Timer;
import utils.Auth;
import utils.MsgBox;

/**
 *
 * @author luudi
 */
public class MAIN extends javax.swing.JFrame {

    private Frame parentFrame;

    /**
     * Creates new form MAIN
     */
    public MAIN() {
        initComponents();
        init();
    }

    void init() {
        setTitle("TechZone");
        setLocationRelativeTo(null);
        new Timer(1000, new ActionListener() {
            SimpleDateFormat format = new SimpleDateFormat("hh:mm:ss a");

            @Override
            public void actionPerformed(ActionEvent e) {
                 lblDongHo2.setText(format.format(new Date()));
            }

        }).start();
        this.openLogin(new Frame());
        this.openWelcome(new Frame());
    }
    
    
    
    void openHome(){
        if (Auth.isLogin()) {
            HomeJPanel sachPanel = new HomeJPanel();
            pnlChinh.removeAll();
            sachPanel.setSize(pnlChinh.getWidth(), pnlChinh.getHeight());
            sachPanel.setLocation(0, 0);
            pnlChinh.add(sachPanel);
            pnlChinh.revalidate();
            pnlChinh.repaint();
        } else {
            MsgBox.alert(this, "Vui lòng đăng nhập");
        }
    }
    
    
    void openSach(){
        if (Auth.isLogin()) {
            SachJPanel sachPanel = new SachJPanel();
            pnlChinh.removeAll();
            sachPanel.setSize(pnlChinh.getWidth(), pnlChinh.getHeight());
            sachPanel.setLocation(0, 0);
            pnlChinh.add(sachPanel);
            pnlChinh.revalidate();
            pnlChinh.repaint();
        } else {
            MsgBox.alert(this, "Vui lòng đăng nhập");
        }
    }
    
    void openTheLoai() {
        if (Auth.isLogin()) {
            TheLoaiJPanel loaiSachPanel = new TheLoaiJPanel();
            pnlChinh.removeAll();
            loaiSachPanel.setSize(pnlChinh.getWidth(), pnlChinh.getHeight());
            loaiSachPanel.setLocation(0, 0);
            pnlChinh.add(loaiSachPanel);
            pnlChinh.revalidate();
            pnlChinh.repaint();
        } else {
            MsgBox.alert(this, "Vui lòng đăng nhập");
        }
    }

    void openTacGia() {
        if (Auth.isLogin()) {
            TacGiaJPanel tacGiaPanel = new TacGiaJPanel();
            pnlChinh.removeAll();
            tacGiaPanel.setSize(pnlChinh.getWidth(), pnlChinh.getHeight());
            tacGiaPanel.setLocation(0, 0);
            pnlChinh.add(tacGiaPanel);
            pnlChinh.revalidate();
            pnlChinh.repaint();
        } else {
            MsgBox.alert(this, "Vui lòng đăng nhập");
        }
    }

    void openNhanVien() {
        if (Auth.isLogin()) {
            NhanVienJPanel nhanVienPanel = new NhanVienJPanel();
            pnlChinh.removeAll();
            nhanVienPanel.setSize(pnlChinh.getWidth(), pnlChinh.getHeight());
            nhanVienPanel.setLocation(0, 0);
            pnlChinh.add(nhanVienPanel);
            pnlChinh.revalidate();
            pnlChinh.repaint();
        } else {
            MsgBox.alert(this, "Vui lòng đăng nhập");
        }
    }

    void openThanhVien() {
        if (Auth.isLogin()) {
            ThanhVienJPanel thanhVienPanel = new ThanhVienJPanel();
            pnlChinh.removeAll();
            thanhVienPanel.setSize(pnlChinh.getWidth(), pnlChinh.getHeight());
            thanhVienPanel.setLocation(0, 0);
            pnlChinh.add(thanhVienPanel);
            pnlChinh.revalidate();
            pnlChinh.repaint();
        } else {
            MsgBox.alert(this, "Vui lòng đăng nhập");
        }
    }

    void openPhieuMuon() {
        if (Auth.isLogin()) {
            PhieuMuonJPanel phieuMuonPanel = new PhieuMuonJPanel();
            pnlChinh.removeAll();
            phieuMuonPanel.setSize(pnlChinh.getWidth(), pnlChinh.getHeight());
            phieuMuonPanel.setLocation(0, 0);
            pnlChinh.add(phieuMuonPanel);
            pnlChinh.revalidate();
            pnlChinh.repaint();
        } else {
            MsgBox.alert(this, "Vui lòng đăng nhập");
        }
    }

    
    void openChiTietPhieuMuon() {
        if(Auth.isLogin()){
         }else{
             MsgBox.alert(this, "Vui long dang nhap");
         }  
    }
    
     void openThongKe() {
        if (Auth.isLogin()) {
            THONGKEJPP tk = new THONGKEJPP();
            pnlChinh.removeAll();
            tk.setSize(pnlChinh.getWidth(), pnlChinh.getHeight());
            tk.setLocation(0, 0);
            pnlChinh.add(tk);
            pnlChinh.revalidate();
            pnlChinh.repaint();
        } else {
            MsgBox.alert(this, "Vui lòng đăng nhập");
        }
    }

    void openWelcome(Frame parentFrame) {
        new ChaoJDialog(parentFrame, true).setVisible(true);
    }
    
    
    void openLogin(Frame parentFrame) {
        new view_2.DangNhap1(parentFrame, true).setVisible(true);
    }
    
    void Login() {
        Auth.isLogin();
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        pnlChinh = new javax.swing.JPanel();
        lblDongHo = new javax.swing.JLabel();
        btnLoaiSach5 = new javax.swing.JButton();
        jButton4 = new javax.swing.JButton();
        btnThanhVien3 = new javax.swing.JButton();
        jButton12 = new javax.swing.JButton();
        btnThongKe4 = new javax.swing.JButton();
        jButton11 = new javax.swing.JButton();
        btnTacGia5 = new javax.swing.JButton();
        lblDongHo2 = new javax.swing.JLabel();
        pnThanhNgang = new javax.swing.JPanel();
        jButton1 = new javax.swing.JButton();
        btnSach2 = new javax.swing.JButton();
        btnLoaiSach2 = new javax.swing.JButton();
        btnTacGia2 = new javax.swing.JButton();
        jButton5 = new javax.swing.JButton();
        jButton6 = new javax.swing.JButton();
        btnThanhVien = new javax.swing.JButton();
        btnThongKe = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        pnlChinh.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));

        lblDongHo.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Icon/Alarm.png"))); // NOI18N
        lblDongHo.setText("10:37:44 AM");

        btnLoaiSach5.setFont(new java.awt.Font("Segoe UI Semibold", 0, 14)); // NOI18N
        btnLoaiSach5.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Icon/17.png"))); // NOI18N
        btnLoaiSach5.setText("Thể Loại");
        btnLoaiSach5.setBorder(null);
        btnLoaiSach5.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        btnLoaiSach5.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        btnLoaiSach5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnLoaiSach5btnLoaiSach3ActionPerformed(evt);
            }
        });

        jButton4.setFont(new java.awt.Font("Segoe UI Semibold", 0, 18)); // NOI18N
        jButton4.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Icon/13.png"))); // NOI18N
        jButton4.setText("Trang chủ");
        jButton4.setBorder(null);
        jButton4.setHideActionText(true);
        jButton4.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        jButton4.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        jButton4.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jButton4jButton2MouseClicked(evt);
            }
        });
        jButton4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton4jButton2ActionPerformed(evt);
            }
        });

        btnThanhVien3.setFont(new java.awt.Font("Segoe UI Semibold", 0, 14)); // NOI18N
        btnThanhVien3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Icon/18.png"))); // NOI18N
        btnThanhVien3.setText("Thành viên");
        btnThanhVien3.setBorder(null);
        btnThanhVien3.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        btnThanhVien3.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        btnThanhVien3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnThanhVien3btnThanhVien1ActionPerformed(evt);
            }
        });

        jButton12.setFont(new java.awt.Font("Segoe UI Semibold", 0, 14)); // NOI18N
        jButton12.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Icon/19.png"))); // NOI18N
        jButton12.setText("Phiếu mượn");
        jButton12.setToolTipText("");
        jButton12.setBorder(null);
        jButton12.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        jButton12.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        jButton12.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton12jButton8ActionPerformed(evt);
            }
        });

        btnThongKe4.setFont(new java.awt.Font("Segoe UI Semibold", 0, 14)); // NOI18N
        btnThongKe4.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Icon/20.png"))); // NOI18N
        btnThongKe4.setText("Thống Kê");
        btnThongKe4.setBorder(null);
        btnThongKe4.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        btnThongKe4.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        btnThongKe4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnThongKe4btnThongKe2ActionPerformed(evt);
            }
        });

        jButton11.setFont(new java.awt.Font("Segoe UI Semibold", 0, 14)); // NOI18N
        jButton11.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Icon/16.png"))); // NOI18N
        jButton11.setText("Nhân viên");
        jButton11.setBorder(null);
        jButton11.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        jButton11.setMaximumSize(new java.awt.Dimension(84, 53));
        jButton11.setMinimumSize(new java.awt.Dimension(84, 53));
        jButton11.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        jButton11.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton11jButton7ActionPerformed(evt);
            }
        });

        btnTacGia5.setFont(new java.awt.Font("Segoe UI Semibold", 0, 14)); // NOI18N
        btnTacGia5.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Icon/15.png"))); // NOI18N
        btnTacGia5.setText("Tác giả");
        btnTacGia5.setBorder(null);
        btnTacGia5.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        btnTacGia5.setPreferredSize(new java.awt.Dimension(100, 125));
        btnTacGia5.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        btnTacGia5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnTacGia5btnTacGia3ActionPerformed(evt);
            }
        });

        lblDongHo2.setFont(new java.awt.Font("Segoe UI Semibold", 0, 18)); // NOI18N
        lblDongHo2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Icon/21.png"))); // NOI18N
        lblDongHo2.setText("10:37:44 AM");

        javax.swing.GroupLayout pnlChinhLayout = new javax.swing.GroupLayout(pnlChinh);
        pnlChinh.setLayout(pnlChinhLayout);
        pnlChinhLayout.setHorizontalGroup(
            pnlChinhLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlChinhLayout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(pnlChinhLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(lblDongHo, javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, pnlChinhLayout.createSequentialGroup()
                        .addComponent(jButton4, javax.swing.GroupLayout.PREFERRED_SIZE, 174, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(160, 160, 160)
                        .addComponent(btnTacGia5, javax.swing.GroupLayout.PREFERRED_SIZE, 135, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(98, 98, 98)))
                .addContainerGap())
            .addGroup(pnlChinhLayout.createSequentialGroup()
                .addGap(158, 158, 158)
                .addGroup(pnlChinhLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(btnThanhVien3, javax.swing.GroupLayout.PREFERRED_SIZE, 135, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnLoaiSach5, javax.swing.GroupLayout.PREFERRED_SIZE, 135, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGroup(pnlChinhLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(pnlChinhLayout.createSequentialGroup()
                        .addGap(127, 127, 127)
                        .addComponent(jButton11, javax.swing.GroupLayout.PREFERRED_SIZE, 135, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(pnlChinhLayout.createSequentialGroup()
                        .addGap(130, 130, 130)
                        .addComponent(btnThongKe4, javax.swing.GroupLayout.PREFERRED_SIZE, 135, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 170, Short.MAX_VALUE)
                .addComponent(jButton12, javax.swing.GroupLayout.PREFERRED_SIZE, 135, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(115, 115, 115))
            .addGroup(pnlChinhLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(pnlChinhLayout.createSequentialGroup()
                    .addGap(147, 147, 147)
                    .addComponent(lblDongHo2, javax.swing.GroupLayout.PREFERRED_SIZE, 174, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addContainerGap(657, Short.MAX_VALUE)))
        );
        pnlChinhLayout.setVerticalGroup(
            pnlChinhLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, pnlChinhLayout.createSequentialGroup()
                .addGap(30, 30, 30)
                .addGroup(pnlChinhLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(pnlChinhLayout.createSequentialGroup()
                        .addComponent(btnTacGia5, javax.swing.GroupLayout.PREFERRED_SIZE, 155, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jButton12, javax.swing.GroupLayout.PREFERRED_SIZE, 155, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(48, 48, 48))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, pnlChinhLayout.createSequentialGroup()
                        .addGroup(pnlChinhLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(btnThanhVien3, javax.swing.GroupLayout.PREFERRED_SIZE, 155, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(pnlChinhLayout.createSequentialGroup()
                                .addComponent(jButton11, javax.swing.GroupLayout.PREFERRED_SIZE, 155, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(51, 51, 51)
                                .addComponent(jButton4, javax.swing.GroupLayout.PREFERRED_SIZE, 175, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 50, Short.MAX_VALUE)
                        .addGroup(pnlChinhLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(btnThongKe4, javax.swing.GroupLayout.PREFERRED_SIZE, 155, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(pnlChinhLayout.createSequentialGroup()
                                .addComponent(btnLoaiSach5, javax.swing.GroupLayout.PREFERRED_SIZE, 155, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addComponent(lblDongHo)))
                        .addContainerGap())))
            .addGroup(pnlChinhLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(pnlChinhLayout.createSequentialGroup()
                    .addGap(305, 305, 305)
                    .addComponent(lblDongHo2, javax.swing.GroupLayout.PREFERRED_SIZE, 53, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addContainerGap(306, Short.MAX_VALUE)))
        );

        pnThanhNgang.setBackground(new java.awt.Color(112, 128, 144));
        pnThanhNgang.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));

        jButton1.setBackground(new java.awt.Color(119, 136, 153));
        jButton1.setFont(new java.awt.Font("Segoe UI Semibold", 0, 16)); // NOI18N
        jButton1.setForeground(new java.awt.Color(255, 255, 255));
        jButton1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Icon/2.png"))); // NOI18N
        jButton1.setText("Trang chủ");
        jButton1.setBorder(null);
        jButton1.setHideActionText(true);
        jButton1.setHorizontalTextPosition(javax.swing.SwingConstants.RIGHT);
        jButton1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jButton1MouseClicked(evt);
            }
        });
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        btnSach2.setBackground(new java.awt.Color(119, 136, 153));
        btnSach2.setFont(new java.awt.Font("Segoe UI Semibold", 0, 16)); // NOI18N
        btnSach2.setForeground(new java.awt.Color(255, 255, 255));
        btnSach2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Icon/3.png"))); // NOI18N
        btnSach2.setText(" Sách");
        btnSach2.setBorder(null);
        btnSach2.setHideActionText(true);
        btnSach2.setHorizontalTextPosition(javax.swing.SwingConstants.RIGHT);
        btnSach2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSach2ActionPerformed(evt);
            }
        });

        btnLoaiSach2.setBackground(new java.awt.Color(119, 136, 153));
        btnLoaiSach2.setFont(new java.awt.Font("Segoe UI Semibold", 0, 16)); // NOI18N
        btnLoaiSach2.setForeground(new java.awt.Color(255, 255, 255));
        btnLoaiSach2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Icon/4.png"))); // NOI18N
        btnLoaiSach2.setText("Thể Loại");
        btnLoaiSach2.setBorder(null);
        btnLoaiSach2.setHorizontalTextPosition(javax.swing.SwingConstants.RIGHT);
        btnLoaiSach2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnLoaiSach2ActionPerformed(evt);
            }
        });

        btnTacGia2.setBackground(new java.awt.Color(119, 136, 153));
        btnTacGia2.setFont(new java.awt.Font("Segoe UI Semibold", 0, 16)); // NOI18N
        btnTacGia2.setForeground(new java.awt.Color(255, 255, 255));
        btnTacGia2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Icon/5.png"))); // NOI18N
        btnTacGia2.setText("Tác giả");
        btnTacGia2.setBorder(null);
        btnTacGia2.setHorizontalTextPosition(javax.swing.SwingConstants.RIGHT);
        btnTacGia2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnTacGia2ActionPerformed(evt);
            }
        });

        jButton5.setBackground(new java.awt.Color(119, 136, 153));
        jButton5.setFont(new java.awt.Font("Segoe UI Semibold", 0, 16)); // NOI18N
        jButton5.setForeground(new java.awt.Color(255, 255, 255));
        jButton5.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Icon/6.png"))); // NOI18N
        jButton5.setText("Nhân viên");
        jButton5.setBorder(null);
        jButton5.setHorizontalTextPosition(javax.swing.SwingConstants.RIGHT);
        jButton5.setMaximumSize(new java.awt.Dimension(84, 53));
        jButton5.setMinimumSize(new java.awt.Dimension(84, 53));
        jButton5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton5ActionPerformed(evt);
            }
        });

        jButton6.setBackground(new java.awt.Color(119, 136, 153));
        jButton6.setFont(new java.awt.Font("Segoe UI Semibold", 0, 16)); // NOI18N
        jButton6.setForeground(new java.awt.Color(255, 255, 255));
        jButton6.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Icon/8..png"))); // NOI18N
        jButton6.setText("Phiếu mượn");
        jButton6.setToolTipText("");
        jButton6.setBorder(null);
        jButton6.setHorizontalTextPosition(javax.swing.SwingConstants.RIGHT);
        jButton6.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton6ActionPerformed(evt);
            }
        });

        btnThanhVien.setBackground(new java.awt.Color(119, 136, 153));
        btnThanhVien.setFont(new java.awt.Font("Segoe UI Semibold", 0, 16)); // NOI18N
        btnThanhVien.setForeground(new java.awt.Color(255, 255, 255));
        btnThanhVien.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Icon/7.png"))); // NOI18N
        btnThanhVien.setText("Thành viên");
        btnThanhVien.setBorder(null);
        btnThanhVien.setHorizontalTextPosition(javax.swing.SwingConstants.RIGHT);
        btnThanhVien.setPreferredSize(new java.awt.Dimension(140, 25));
        btnThanhVien.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnThanhVienActionPerformed(evt);
            }
        });

        btnThongKe.setBackground(new java.awt.Color(119, 136, 153));
        btnThongKe.setFont(new java.awt.Font("Segoe UI Semibold", 0, 16)); // NOI18N
        btnThongKe.setForeground(new java.awt.Color(255, 255, 255));
        btnThongKe.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Icon/9.png"))); // NOI18N
        btnThongKe.setText("Thống Kê");
        btnThongKe.setBorder(null);
        btnThongKe.setHorizontalTextPosition(javax.swing.SwingConstants.RIGHT);
        btnThongKe.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnThongKeActionPerformed(evt);
            }
        });

        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Icon/1.png"))); // NOI18N

        javax.swing.GroupLayout pnThanhNgangLayout = new javax.swing.GroupLayout(pnThanhNgang);
        pnThanhNgang.setLayout(pnThanhNgangLayout);
        pnThanhNgangLayout.setHorizontalGroup(
            pnThanhNgangLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, pnThanhNgangLayout.createSequentialGroup()
                .addGroup(pnThanhNgangLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, pnThanhNgangLayout.createSequentialGroup()
                        .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 14, Short.MAX_VALUE))
                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, pnThanhNgangLayout.createSequentialGroup()
                        .addGap(10, 10, 10)
                        .addGroup(pnThanhNgangLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(btnThongKe, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jButton6, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(btnThanhVien, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jButton5, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(btnTacGia2, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(btnLoaiSach2, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(btnSach2, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jButton1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
                .addGap(10, 10, 10))
        );
        pnThanhNgangLayout.setVerticalGroup(
            pnThanhNgangLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnThanhNgangLayout.createSequentialGroup()
                .addGap(0, 0, 0)
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 124, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(20, 20, 20)
                .addComponent(jButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(30, 30, 30)
                .addComponent(btnSach2, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(30, 30, 30)
                .addComponent(btnLoaiSach2, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(28, 28, 28)
                .addComponent(btnTacGia2, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(32, 32, 32)
                .addComponent(jButton5, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(30, 30, 30)
                .addComponent(btnThanhVien, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(34, 34, 34)
                .addComponent(jButton6, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(26, 26, 26)
                .addComponent(btnThongKe, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(30, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addComponent(pnThanhNgang, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(pnlChinh, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(pnlChinh, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(pnThanhNgang, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jButton1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton1MouseClicked

    }//GEN-LAST:event_jButton1MouseClicked

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
          //jTabbedPane1.setSelectedIndex(0);       // TODO add your handling code here:
    }//GEN-LAST:event_jButton1ActionPerformed

    private void btnSach2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSach2ActionPerformed
        openSach();
    }//GEN-LAST:event_btnSach2ActionPerformed

    private void btnLoaiSach2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnLoaiSach2ActionPerformed
        openTheLoai();
    }//GEN-LAST:event_btnLoaiSach2ActionPerformed

    private void btnTacGia2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnTacGia2ActionPerformed
        // TODO add your handling code here:
        openTacGia();
    }//GEN-LAST:event_btnTacGia2ActionPerformed

    private void jButton5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton5ActionPerformed
        openNhanVien();  // TODO add your handling code here:
    }//GEN-LAST:event_jButton5ActionPerformed

    private void jButton6ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton6ActionPerformed
        openPhieuMuon();        // TODO add your handling code here:
    }//GEN-LAST:event_jButton6ActionPerformed

    private void btnThanhVienActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnThanhVienActionPerformed
        openThanhVien();    // TODO add your handling code here:
    }//GEN-LAST:event_btnThanhVienActionPerformed

    private void btnThongKeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnThongKeActionPerformed
        openThongKe();
    }//GEN-LAST:event_btnThongKeActionPerformed

    private void btnTacGia5btnTacGia3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnTacGia5btnTacGia3ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_btnTacGia5btnTacGia3ActionPerformed

    private void jButton11jButton7ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton11jButton7ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton11jButton7ActionPerformed

    private void btnThongKe4btnThongKe2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnThongKe4btnThongKe2ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_btnThongKe4btnThongKe2ActionPerformed

    private void jButton12jButton8ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton12jButton8ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton12jButton8ActionPerformed

    private void btnThanhVien3btnThanhVien1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnThanhVien3btnThanhVien1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_btnThanhVien3btnThanhVien1ActionPerformed

    private void jButton4jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton4jButton2ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton4jButton2ActionPerformed

    private void jButton4jButton2MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton4jButton2MouseClicked
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton4jButton2MouseClicked

    private void btnLoaiSach5btnLoaiSach3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnLoaiSach5btnLoaiSach3ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_btnLoaiSach5btnLoaiSach3ActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(MAIN.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(MAIN.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(MAIN.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(MAIN.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                    new MAIN().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnLoaiSach2;
    private javax.swing.JButton btnLoaiSach5;
    private javax.swing.JButton btnSach2;
    private javax.swing.JButton btnTacGia2;
    private javax.swing.JButton btnTacGia5;
    private javax.swing.JButton btnThanhVien;
    private javax.swing.JButton btnThanhVien3;
    private javax.swing.JButton btnThongKe;
    private javax.swing.JButton btnThongKe4;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton11;
    private javax.swing.JButton jButton12;
    private javax.swing.JButton jButton4;
    private javax.swing.JButton jButton5;
    private javax.swing.JButton jButton6;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel lblDongHo;
    private javax.swing.JLabel lblDongHo2;
    private javax.swing.JPanel pnThanhNgang;
    private javax.swing.JPanel pnlChinh;
    // End of variables declaration//GEN-END:variables
}
